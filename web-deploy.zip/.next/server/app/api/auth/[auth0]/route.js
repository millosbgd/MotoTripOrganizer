var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/[auth0]/route.js")
R.c("server/chunks/[root-of-the-server]__3cb92403._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_[auth0]_route_actions_52fcedfb.js")
R.m(9129)
module.exports=R.m(9129).exports
