var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/me/route.js")
R.c("server/chunks/[root-of-the-server]__93f77c85._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_me_route_actions_3ee82308.js")
R.m(21455)
module.exports=R.m(21455).exports
