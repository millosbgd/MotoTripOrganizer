var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/hello/route.js")
R.c("server/chunks/[root-of-the-server]__2d186905._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_hello_route_actions_e18b7858.js")
R.m(97202)
module.exports=R.m(97202).exports
